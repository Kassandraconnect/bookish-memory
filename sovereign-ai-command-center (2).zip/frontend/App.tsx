import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar.tsx';
import { Dashboard } from './components/Dashboard.tsx';
import { ChatInterface } from './components/ChatInterface.tsx';
import { Projects } from './components/Projects.tsx';
import { Assets } from './components/Assets.tsx';
import { Logs } from './components/Logs.tsx';
import { Settings } from './components/Settings.tsx';
import { ViewState } from './types.ts';
import { StoreProvider } from './store.tsx';

const AppContent: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.DASHBOARD);

  const renderView = () => {
    switch (currentView) {
      case ViewState.DASHBOARD: return <Dashboard />;
      case ViewState.CHAT: return <ChatInterface />;
      case ViewState.PROJECTS: return <Projects />;
      case ViewState.ASSETS: return <Assets />;
      case ViewState.LOGS: return <Logs />;
      case ViewState.SETTINGS: return <Settings />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-slate-50 overflow-hidden selection:bg-brand-200 selection:text-brand-900 font-sans">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      
      <main className="flex-1 h-full overflow-y-auto relative flex flex-col">
        {/* Ultra-premium animated background */}
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-brand-400/5 blur-[120px] animate-pulse-slow" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-blue-400/5 blur-[150px] animate-pulse-slow" style={{ animationDelay: '1.5s' }} />
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMiIgY3k9IjIiIHI9IjEiIGZpbGw9IiNlMmU4ZjAiLz48L3N2Zz4=')] opacity-40" />
        </div>
        
        <div className="relative z-10 flex-1 h-full">
          {renderView()}
        </div>
      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
};

export default App;
