import React, { useState } from 'react';
import { Plus, MoreVertical, Clock, ArrowRight, FolderKanban, CheckCircle2, Circle, Tag, Play } from 'lucide-react';
import { useStore } from '../store.tsx';
import { Modal } from './Modal.tsx';
import { Project } from '../types.ts';

export const Projects: React.FC = () => {
  const { projects, addProject, toggleTask } = useStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newProject, setNewProject] = useState({ name: '', description: '', status: 'planning' as Project['status'], tags: '' });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProject.name.trim()) return;
    addProject({
      name: newProject.name,
      description: newProject.description,
      status: newProject.status,
      tags: newProject.tags.split(',').map(t => t.trim()).filter(t => t)
    });
    setIsModalOpen(false);
    setNewProject({ name: '', description: '', status: 'planning', tags: '' });
  };

  const getStatusStyles = (status: Project['status']) => {
    switch (status) {
      case 'active': return 'bg-blue-50 text-blue-700 border-blue-200 ring-blue-500/20';
      case 'planning': return 'bg-slate-50 text-slate-700 border-slate-200 ring-slate-500/20';
      case 'review': return 'bg-amber-50 text-amber-700 border-amber-200 ring-amber-500/20';
      case 'completed': return 'bg-emerald-50 text-emerald-700 border-emerald-200 ring-emerald-500/20';
      default: return 'bg-slate-50 text-slate-700 border-slate-200 ring-slate-500/20';
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex flex-col md:flex-row md:justify-between md:items-end gap-4 bg-white/80 backdrop-blur-xl p-6 rounded-2xl border border-slate-200/80 shadow-sm">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2 bg-brand-50 rounded-lg border border-brand-100">
              <FolderKanban className="w-6 h-6 text-brand-600" />
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Active Operations</h2>
          </div>
          <p className="text-slate-500 text-sm ml-12 font-medium">Manage, monitor, and direct autonomous agent projects.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-brand-600 transition-all shadow-md hover:shadow-lg active:scale-95"
        >
          <Plus className="w-4 h-4" /> Issue Directive
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {projects.map(project => (
          <div key={project.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group overflow-hidden relative">
            {/* Top Accent Line */}
            <div className={`absolute top-0 left-0 right-0 h-1 ${project.status === 'active' ? 'bg-blue-500' : project.status === 'review' ? 'bg-amber-500' : project.status === 'completed' ? 'bg-emerald-500' : 'bg-slate-300'}`} />
            
            <div className="p-6 flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-4">
                <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border ring-1 ${getStatusStyles(project.status)}`}>
                  {project.status}
                </span>
                <button className="text-slate-400 hover:text-slate-900 transition-colors p-1 rounded-md hover:bg-slate-100">
                  <MoreVertical className="w-5 h-5" />
                </button>
              </div>
              
              <h3 className="text-xl font-extrabold text-slate-900 mb-2 leading-tight">{project.name}</h3>
              <p className="text-sm text-slate-500 mb-5 flex-1 line-clamp-3 font-medium leading-relaxed">{project.description}</p>
              
              {/* Tags */}
              {project.tags && project.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag, i) => (
                    <span key={i} className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-slate-100 text-slate-600 text-[10px] font-bold uppercase tracking-wider border border-slate-200">
                      <Tag className="w-3 h-3" /> {tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Tasks Preview */}
              {project.tasks && project.tasks.length > 0 && (
                <div className="mb-6 space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Sub-Routines</p>
                  {project.tasks.slice(0, 3).map(task => (
                    <div key={task.id} className="flex items-start gap-2 group/task cursor-pointer" onClick={() => toggleTask(project.id, task.id)}>
                      {task.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-300 group-hover/task:text-brand-400 shrink-0 mt-0.5 transition-colors" />
                      )}
                      <span className={`text-sm font-medium truncate ${task.completed ? 'text-slate-400 line-through' : 'text-slate-700'}`}>
                        {task.title}
                      </span>
                    </div>
                  ))}
                  {project.tasks.length > 3 && (
                    <p className="text-xs text-slate-400 font-medium pl-6">+{project.tasks.length - 3} more routines...</p>
                  )}
                </div>
              )}
              
              {/* Progress */}
              <div className="space-y-2.5 mt-auto">
                <div className="flex justify-between text-sm items-end">
                  <span className="text-slate-500 font-bold uppercase tracking-wider text-[10px]">Completion</span>
                  <span className="text-slate-900 font-black text-lg leading-none">{project.progress}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden shadow-inner">
                  <div 
                    className={`h-full rounded-full transition-all duration-1000 ease-out relative overflow-hidden ${
                      project.progress === 100 ? 'bg-emerald-500' : 'bg-gradient-to-r from-brand-500 to-brand-400'
                    }`}
                    style={{ width: `${project.progress}%` }}
                  >
                    {project.progress > 0 && project.progress < 100 && (
                      <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.2)_50%,transparent_75%,transparent_100%)] bg-[length:20px_20px] animate-[scanline_1s_linear_infinite]" />
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono font-medium">
                <Clock className="w-3.5 h-3.5" />
                {project.updatedAt.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
              </div>
              <div className="flex gap-2">
                {project.status === 'planning' && (
                  <button className="p-1.5 text-brand-600 hover:bg-brand-100 rounded-md transition-colors" title="Deploy">
                    <Play className="w-4 h-4" />
                  </button>
                )}
                <button className="text-slate-600 hover:text-brand-600 text-sm font-bold flex items-center gap-1 transition-colors">
                  Manage <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Issue New Directive">
        <form onSubmit={handleCreate} className="space-y-5">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1.5">Directive Name</label>
            <input 
              type="text" required autoFocus
              value={newProject.name} onChange={e => setNewProject({...newProject, name: e.target.value})}
              className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none transition-all font-medium"
              placeholder="e.g., Automated Code Review"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1.5">Description & Parameters</label>
            <textarea 
              required rows={4}
              value={newProject.description} onChange={e => setNewProject({...newProject, description: e.target.value})}
              className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none transition-all resize-none font-medium"
              placeholder="Define the scope and objectives for the agent..."
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1.5">Initial Status</label>
              <select 
                value={newProject.status} onChange={e => setNewProject({...newProject, status: e.target.value as Project['status']})}
                className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none transition-all bg-white font-medium"
              >
                <option value="planning">Planning (Draft)</option>
                <option value="active">Active (Deploy Immediately)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1.5">Tags (Comma separated)</label>
              <input 
                type="text" 
                value={newProject.tags} onChange={e => setNewProject({...newProject, tags: e.target.value})}
                className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none transition-all font-medium"
                placeholder="e.g., DevOps, High Priority"
              />
            </div>
          </div>
          <div className="pt-6 flex justify-end gap-3 border-t border-slate-100">
            <button type="button" onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors">
              Cancel
            </button>
            <button type="submit" className="px-5 py-2.5 text-sm font-bold text-white bg-slate-900 hover:bg-brand-600 rounded-xl transition-all shadow-md active:scale-95">
              Deploy Directive
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
