import React from 'react';
import { LayoutDashboard, MessageSquare, FolderKanban, KeyRound, ScrollText, ShieldCheck, Settings, Cpu, Activity } from 'lucide-react';
import { ViewState } from '../types.ts';

interface SidebarProps {
  currentView: ViewState;
  onViewChange: (view: ViewState) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange }) => {
  const navItems = [
    { id: ViewState.DASHBOARD, label: 'Command Center', icon: LayoutDashboard },
    { id: ViewState.CHAT, label: 'Agent Interface', icon: MessageSquare },
    { id: ViewState.PROJECTS, label: 'Active Ops', icon: FolderKanban },
    { id: ViewState.ASSETS, label: 'Secure Vault', icon: KeyRound },
    { id: ViewState.LOGS, label: 'System Logs', icon: ScrollText },
    { id: ViewState.SETTINGS, label: 'System Settings', icon: Settings },
  ];

  return (
    <aside className="w-72 bg-white/80 backdrop-blur-xl border-r border-slate-200/80 flex flex-col h-screen sticky top-0 z-50 shadow-[4px_0_24px_-12px_rgba(0,0,0,0.05)]">
      <div className="p-6 flex items-center gap-4 border-b border-slate-100/80">
        <div className="relative">
          <div className="absolute inset-0 bg-brand-500 blur-md opacity-40 rounded-xl animate-pulse-slow" />
          <div className="relative w-10 h-10 bg-gradient-to-br from-brand-500 to-brand-700 rounded-xl flex items-center justify-center shadow-lg shadow-brand-500/20 border border-brand-400/50">
            <ShieldCheck className="w-6 h-6 text-white" />
          </div>
        </div>
        <div>
          <h1 className="font-extrabold text-slate-900 tracking-tight text-lg leading-none">SOVEREIGN</h1>
          <p className="text-[10px] font-mono text-brand-600 font-bold uppercase tracking-widest mt-1 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-500 animate-pulse" /> Local Enclave
          </p>
        </div>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 px-3">Core Modules</div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-300 text-sm font-semibold group relative overflow-hidden ${
                isActive
                  ? 'text-brand-700 shadow-sm border border-brand-200/50 bg-gradient-to-r from-brand-50 to-white'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent'
              }`}
            >
              {isActive && <div className="absolute left-0 top-0 bottom-0 w-1 bg-brand-500 rounded-r-full" />}
              <Icon className={`w-5 h-5 transition-colors duration-300 ${isActive ? 'text-brand-600' : 'text-slate-400 group-hover:text-slate-600'}`} />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-100/80 bg-slate-50/50">
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-colors" />
          
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-emerald-500" /> Status
            </span>
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-[11px] text-slate-500 font-medium">Agent Core</span>
              <span className="text-[11px] font-mono font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">ONLINE</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[11px] text-slate-500 font-medium">Telemetry</span>
              <span className="text-[11px] font-mono font-bold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">BLOCKED</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[11px] text-slate-500 font-medium">Compute</span>
              <span className="text-[11px] font-mono font-bold text-brand-600 flex items-center gap-1">
                <Cpu className="w-3 h-3" /> Local
              </span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};
