import React, { useMemo } from 'react';
import { Activity, Cpu, Network, Shield, Zap, Clock, ArrowRight, HardDrive, Server } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { useStore } from '../store.tsx';

const mockActivityData = [
  { time: '00:00', ops: 12, compute: 20 }, { time: '04:00', ops: 19, compute: 35 },
  { time: '08:00', ops: 45, compute: 60 }, { time: '12:00', ops: 82, compute: 90 },
  { time: '16:00', ops: 65, compute: 75 }, { time: '20:00', ops: 34, compute: 45 },
  { time: '24:00', ops: 22, compute: 30 },
];

const mockResourceData = [
  { name: 'Core 1', load: 85 }, { name: 'Core 2', load: 42 },
  { name: 'Core 3', load: 90 }, { name: 'Core 4', load: 25 },
  { name: 'Core 5', load: 60 }, { name: 'Core 6', load: 75 },
];

export const Dashboard: React.FC = () => {
  const { projects, logs, assets } = useStore();

  const activeProjectsCount = projects.filter(p => p.status === 'active').length;
  const recentLogs = useMemo(() => logs.slice(0, 6), [logs]);
  const actionLogsCount = logs.filter(l => l.level === 'action').length;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex flex-col md:flex-row md:justify-between md:items-end gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Command Center</h2>
          <p className="text-slate-500 text-sm mt-1.5 font-medium">Real-time overview of autonomous operations and system health.</p>
        </div>
        <div className="flex gap-3">
          <div className="glass px-4 py-2 rounded-xl flex items-center gap-2 shadow-sm border border-slate-200/60">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Enclave Secured</span>
          </div>
        </div>
      </header>

      {/* Quick Stats - Glassmorphism Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {[
          { label: 'Active Directives', value: activeProjectsCount.toString(), icon: Activity, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100' },
          { label: 'Actions Executed', value: actionLogsCount.toString(), icon: Zap, color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100' },
          { label: 'Secure Assets', value: assets.length.toString(), icon: Shield, color: 'text-brand-600', bg: 'bg-brand-50', border: 'border-brand-100' },
          { label: 'Network Nodes', value: '12', icon: Network, color: 'text-purple-600', bg: 'bg-purple-50', border: 'border-purple-100' },
        ].map((stat, i) => (
          <div key={i} className={`bg-white/80 backdrop-blur-md p-6 rounded-2xl border ${stat.border} shadow-sm hover:shadow-md transition-all duration-300 group relative overflow-hidden`}>
            <div className={`absolute -right-6 -top-6 w-24 h-24 rounded-full ${stat.bg} opacity-50 group-hover:scale-150 transition-transform duration-500 ease-out`} />
            <div className="relative z-10 flex items-center gap-4">
              <div className={`p-3.5 rounded-xl ${stat.bg} shadow-inner`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{stat.label}</p>
                <p className="text-3xl font-black text-slate-900 tracking-tight">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white/90 backdrop-blur-xl p-7 rounded-2xl border border-slate-200/80 shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Agent Activity & Compute</h3>
              <p className="text-xs text-slate-500 mt-1">Volume of operations vs local compute load</p>
            </div>
            <div className="flex items-center gap-4 text-xs font-bold">
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-brand-500" /> Operations</div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-slate-300" /> Compute Load</div>
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockActivityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorOps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0d9488" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#0d9488" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorCompute" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#94a3b8" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#94a3b8" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12, fontWeight: 500 }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12, fontWeight: 500 }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', backgroundColor: 'rgba(255,255,255,0.95)', backdropFilter: 'blur(8px)' }}
                  itemStyle={{ color: '#0f172a', fontWeight: 700 }}
                />
                <Area type="monotone" dataKey="compute" stroke="#94a3b8" strokeWidth={2} fillOpacity={1} fill="url(#colorCompute)" />
                <Area type="monotone" dataKey="ops" stroke="#0d9488" strokeWidth={3} fillOpacity={1} fill="url(#colorOps)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Resource Meters & Recent Activity */}
        <div className="space-y-6">
          {/* Resource Meters */}
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-500/10 rounded-full blur-2xl" />
            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-5 flex items-center gap-2">
              <Server className="w-4 h-4 text-brand-400" /> Local Hardware
            </h3>
            
            <div className="space-y-5 relative z-10">
              <div>
                <div className="flex justify-between text-xs font-mono mb-1.5">
                  <span className="text-slate-400">CPU (M2 Max)</span>
                  <span className="text-brand-400 font-bold">68%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-brand-600 to-brand-400 rounded-full w-[68%]" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs font-mono mb-1.5">
                  <span className="text-slate-400">RAM (64GB)</span>
                  <span className="text-amber-400 font-bold">42GB</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-amber-600 to-amber-400 rounded-full w-[75%]" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs font-mono mb-1.5">
                  <span className="text-slate-400">NPU Load</span>
                  <span className="text-purple-400 font-bold">92%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-purple-600 to-purple-400 rounded-full w-[92%] animate-pulse" />
                </div>
              </div>
            </div>
          </div>

          {/* Recent Activity Feed */}
          <div className="bg-white/90 backdrop-blur-xl p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col h-[280px]">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500" /> Live Event Stream
            </h3>
            <div className="flex-1 overflow-y-auto pr-2 space-y-4 custom-scrollbar">
              {recentLogs.map((log) => (
                <div key={log.id} className="flex gap-3 items-start group">
                  <div className={`mt-0.5 p-1.5 rounded-lg shrink-0 shadow-sm border ${
                    log.level === 'error' ? 'bg-red-50 text-red-600 border-red-100' :
                    log.level === 'warn' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                    log.level === 'action' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                    log.level === 'thought' ? 'bg-purple-50 text-purple-600 border-purple-100' :
                    'bg-slate-50 text-slate-500 border-slate-200'
                  }`}>
                    <Activity className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-slate-800 font-semibold truncate" title={log.message}>
                      {log.message}
                    </p>
                    <p className="text-[10px] text-slate-400 font-mono mt-1 uppercase tracking-wider">
                      {log.timestamp.toLocaleTimeString()} • {log.source}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
