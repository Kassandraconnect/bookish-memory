import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, Cpu, Key, Database, Lock, Smartphone, AlertTriangle, 
  Save, CheckCircle2, ServerOff, Fingerprint, Network, Trash2, Plus, 
  Eye, EyeOff, Activity, SlidersHorizontal
} from 'lucide-react';
import { Modal } from './Modal.tsx';
import { useStore } from '../store.tsx';
import { Asset } from '../types.ts';

type Tab = 'agent' | 'integrations' | 'network' | 'danger';

// Custom Toggle Component
const Toggle: React.FC<{ checked: boolean; onChange: (c: boolean) => void; label: string; description?: string }> = ({ checked, onChange, label, description }) => (
  <div className="flex items-center justify-between py-3">
    <div>
      <p className="text-sm font-medium text-slate-900">{label}</p>
      {description && <p className="text-xs text-slate-500 mt-0.5">{description}</p>}
    </div>
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-brand-500 focus:ring-offset-2 ${checked ? 'bg-brand-600' : 'bg-slate-200'}`}
    >
      <span className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${checked ? 'translate-x-5' : 'translate-x-0'}`} />
    </button>
  </div>
);

export const Settings: React.FC = () => {
  const { addLog, settings, updateSettings, assets, addAsset, removeAsset } = useStore();
  
  // Security Lock State
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [unlockPin, setUnlockPin] = useState('');
  const [unlockError, setUnlockError] = useState(false);

  // Main Settings State
  const [activeTab, setActiveTab] = useState<Tab>('agent');
  const [isSaved, setIsSaved] = useState(false);
  const [localSettings, setLocalSettings] = useState(settings);
  
  // Integrations State
  const [isAddAssetModalOpen, setIsAddAssetModalOpen] = useState(false);
  const [newAsset, setNewAsset] = useState({ name: '', type: 'api_key' as Asset['type'], value: '' });
  const [visibleAssets, setVisibleAssets] = useState<Set<string>>(new Set());

  // Kill Switch State
  const [isKillModalOpen, setIsKillModalOpen] = useState(false);
  const [killStep, setKillStep] = useState<1 | 2 | 3>(1);
  const [killPassword, setKillPassword] = useState('');
  const [killSmsCode, setKillSmsCode] = useState('');
  const [killConfirmText, setKillConfirmText] = useState('');
  const [isTerminated, setIsTerminated] = useState(false);

  // Sync local settings when global settings change
  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (unlockPin === 'admin') {
      setIsUnlocked(true);
      addLog({ level: 'info', source: 'system', message: 'Air-gapped settings panel accessed.' });
    } else {
      setUnlockError(true);
      setUnlockPin('');
      setTimeout(() => setUnlockError(false), 2000);
      addLog({ level: 'warn', source: 'system', message: 'Failed access attempt to settings panel.' });
    }
  };

  const handleSave = () => {
    updateSettings(localSettings);
    setIsSaved(true);
    addLog({ level: 'action', source: 'user', message: 'Core system configurations updated.' });
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleAddAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAsset.name || !newAsset.value) return;
    addAsset({ ...newAsset, projectId: 'global', isSecure: true });
    setIsAddAssetModalOpen(false);
    setNewAsset({ name: '', type: 'api_key', value: '' });
  };

  const toggleAssetVisibility = (id: string) => {
    const newSet = new Set(visibleAssets);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setVisibleAssets(newSet);
  };

  const handleKillSwitchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (killStep === 1 && killPassword === 'admin') {
      setKillStep(2);
      addLog({ level: 'warn', source: 'system', message: 'Protocol Omega initiated. Awaiting SMS verification.' });
    } else if (killStep === 2 && killSmsCode === '000000') {
      setKillStep(3);
      addLog({ level: 'warn', source: 'system', message: 'SMS verified. Awaiting final cryptographic confirmation.' });
    } else if (killStep === 3 && killConfirmText === 'TERMINATE') {
      setIsTerminated(true);
      addLog({ level: 'error', source: 'system', message: 'PROTOCOL OMEGA EXECUTED. AGENT TERMINATED. DATA PURGED.' });
    }
  };

  if (!isUnlocked) {
    return (
      <div className="h-full w-full flex items-center justify-center bg-slate-900 p-4">
        <div className="max-w-md w-full bg-slate-800 rounded-2xl border border-slate-700 shadow-2xl p-8 animate-in zoom-in-95 duration-300">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-slate-900 rounded-full flex items-center justify-center border border-slate-700 shadow-inner">
              <Fingerprint className="w-8 h-8 text-brand-500" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white text-center mb-2">Restricted Area</h2>
          <p className="text-slate-400 text-center text-sm mb-8">
            This configuration panel is air-gapped from the agent. Enter master PIN to proceed.
          </p>
          <form onSubmit={handleUnlock} className="space-y-6">
            <div>
              <input 
                type="password" 
                autoFocus
                value={unlockPin}
                onChange={e => setUnlockPin(e.target.value)}
                className={`w-full bg-slate-900 border ${unlockError ? 'border-red-500 focus:ring-red-500' : 'border-slate-700 focus:ring-brand-500'} rounded-xl px-4 py-4 text-center text-2xl tracking-[0.5em] text-white focus:outline-none focus:ring-2 transition-all font-mono`}
                placeholder="••••"
              />
              {unlockError && <p className="text-red-400 text-xs text-center mt-2 animate-pulse">Access Denied. Unauthorized attempt logged.</p>}
            </div>
            <button 
              type="submit"
              className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 rounded-xl transition-colors shadow-lg shadow-brand-900/20"
            >
              Authenticate
            </button>
          </form>
          <p className="text-center text-xs text-slate-500 mt-6 font-mono">Hint: Use 'admin'</p>
        </div>
      </div>
    );
  }

  if (isTerminated) {
    return (
      <div className="h-full w-full bg-red-950 flex flex-col items-center justify-center text-red-50 p-8 animate-in fade-in duration-1000">
        <ServerOff className="w-32 h-32 text-red-500 mb-8 animate-pulse drop-shadow-[0_0_15px_rgba(239,68,68,0.5)]" />
        <h1 className="text-5xl font-black mb-4 tracking-widest text-transparent bg-clip-text bg-gradient-to-b from-red-100 to-red-500">SYSTEM TERMINATED</h1>
        <div className="max-w-2xl bg-red-900/50 border border-red-800 rounded-xl p-6 backdrop-blur-sm">
          <p className="text-red-200 font-mono text-center leading-relaxed">
            Protocol Omega executed successfully. All agent processes halted. Local data stores cryptographically shredded. Network connections severed. The Sovereign instance is no longer active.
          </p>
        </div>
        <button 
          onClick={() => window.location.reload()}
          className="mt-12 px-8 py-4 bg-red-900 hover:bg-red-800 text-red-100 rounded-xl font-mono text-sm font-bold transition-all border border-red-700 hover:border-red-500 shadow-lg hover:shadow-red-900/50"
        >
          REBOOT SYSTEM (CLEAN SLATE)
        </button>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 pb-24">
      <header className="flex flex-col md:flex-row md:justify-between md:items-end gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2 bg-slate-900 rounded-lg">
              <ShieldAlert className="w-6 h-6 text-brand-400" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900">Master Configuration</h2>
          </div>
          <p className="text-slate-500 text-sm ml-11">Air-gapped control panel. Agent access strictly prohibited.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg">
            <Activity className="w-4 h-4 text-emerald-600" />
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">System Secure</span>
          </div>
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 bg-slate-900 text-white px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-slate-800 transition-all shadow-md hover:shadow-lg active:scale-95"
          >
            {isSaved ? <CheckCircle2 className="w-4 h-4 text-brand-400" /> : <Save className="w-4 h-4" />}
            {isSaved ? 'Config Saved' : 'Apply Changes'}
          </button>
        </div>
      </header>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Settings Navigation */}
        <div className="w-full lg:w-72 shrink-0 space-y-2">
          {[
            { id: 'agent', label: 'Agent Core & Laws', icon: Cpu, desc: 'Model, autonomy, directives' },
            { id: 'integrations', label: 'Integrations & APIs', icon: Key, desc: 'External service access' },
            { id: 'network', label: 'Network & Security', icon: Network, desc: 'Telemetry, firewalls, limits' },
            { id: 'danger', label: 'Danger Zone', icon: AlertTriangle, danger: true, desc: 'Kill switch, data purge' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as Tab)}
              className={`w-full flex items-start gap-4 p-4 rounded-xl text-left transition-all duration-200 ${
                activeTab === tab.id
                  ? tab.danger 
                    ? 'bg-red-50 border-red-200 shadow-sm ring-1 ring-red-500/20' 
                    : 'bg-white border-slate-200 shadow-md ring-1 ring-brand-500/20'
                  : 'bg-transparent border-transparent hover:bg-white hover:shadow-sm border'
              } border`}
            >
              <div className={`p-2 rounded-lg shrink-0 ${
                activeTab === tab.id 
                  ? tab.danger ? 'bg-red-100 text-red-600' : 'bg-brand-50 text-brand-600'
                  : tab.danger ? 'bg-red-50/50 text-red-400' : 'bg-slate-100 text-slate-500'
              }`}>
                <tab.icon className="w-5 h-5" />
              </div>
              <div>
                <p className={`text-sm font-bold ${tab.danger ? 'text-red-700' : 'text-slate-900'}`}>{tab.label}</p>
                <p className={`text-xs mt-0.5 ${tab.danger ? 'text-red-500/80' : 'text-slate-500'}`}>{tab.desc}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Settings Content */}
        <div className="flex-1 bg-white rounded-2xl border border-slate-200 shadow-sm p-6 md:p-8 min-h-[600px]">
          
          {activeTab === 'agent' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <SlidersHorizontal className="w-5 h-5 text-brand-600" /> Core Parameters
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Active Model</label>
                    <select 
                      value={localSettings.model}
                      onChange={e => setLocalSettings({...localSettings, model: e.target.value})}
                      className="w-full border border-slate-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-brand-500 outline-none bg-slate-50 font-medium"
                    >
                      <option value="Gemma 4 26B A4B IT (Local)">Gemma 4 26B A4B IT (Local)</option>
                      <option value="Llama 3 70B Instruct (Local)">Llama 3 70B Instruct (Local)</option>
                      <option value="Mistral 8x22B (Local)">Mistral 8x22B (Local)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Autonomy Level</label>
                    <select 
                      value={localSettings.autonomyLevel}
                      onChange={e => setLocalSettings({...localSettings, autonomyLevel: e.target.value as any})}
                      className="w-full border border-slate-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-brand-500 outline-none bg-slate-50 font-medium"
                    >
                      <option value="strict">Strict (Requires approval for all actions)</option>
                      <option value="supervised">Supervised (Approval for external actions)</option>
                      <option value="autonomous">Fully Autonomous (Unrestricted)</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="flex justify-between text-sm font-medium text-slate-700 mb-2">
                      <span>Creativity / Temperature</span>
                      <span className="text-brand-600 font-mono">{localSettings.temperature.toFixed(2)}</span>
                    </label>
                    <input 
                      type="range" min="0" max="1" step="0.05" 
                      value={localSettings.temperature}
                      onChange={e => setLocalSettings({...localSettings, temperature: parseFloat(e.target.value)})}
                      className="w-full accent-brand-600 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer" 
                    />
                    <div className="flex justify-between text-xs text-slate-400 mt-1">
                      <span>Precise / Analytical</span>
                      <span>Creative / Exploratory</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-slate-100">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold text-slate-900">Immutable Laws</h3>
                  <button 
                    onClick={() => setLocalSettings({...localSettings, immutableLaws: [...localSettings.immutableLaws, '']})}
                    className="text-sm text-brand-600 font-medium hover:text-brand-700 flex items-center gap-1"
                  >
                    <Plus className="w-4 h-4" /> Add Law
                  </button>
                </div>
                <p className="text-sm text-slate-500 mb-4">Hardcoded directives the agent cannot override under any circumstance. Evaluated before every action.</p>
                <div className="space-y-3">
                  {localSettings.immutableLaws.map((law, index) => (
                    <div key={index} className="flex gap-3">
                      <div className="flex-shrink-0 w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center text-slate-500 font-mono text-sm font-bold border border-slate-200">
                        {index + 1}
                      </div>
                      <input 
                        type="text"
                        value={law}
                        onChange={e => {
                          const newLaws = [...localSettings.immutableLaws];
                          newLaws[index] = e.target.value;
                          setLocalSettings({...localSettings, immutableLaws: newLaws});
                        }}
                        className="flex-1 border border-slate-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-brand-500 outline-none font-medium text-slate-800"
                        placeholder="Enter immutable directive..."
                      />
                      <button 
                        onClick={() => {
                          const newLaws = localSettings.immutableLaws.filter((_, i) => i !== index);
                          setLocalSettings({...localSettings, immutableLaws: newLaws});
                        }}
                        className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'integrations' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex justify-between items-end">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 mb-1">External API Connections</h3>
                  <p className="text-sm text-slate-500">Manage keys and credentials for services the agent is authorized to use.</p>
                </div>
                <button 
                  onClick={() => setIsAddAssetModalOpen(true)}
                  className="flex items-center gap-2 bg-slate-100 text-slate-700 px-4 py-2 rounded-lg text-sm font-bold hover:bg-slate-200 transition-colors border border-slate-300"
                >
                  <Plus className="w-4 h-4" /> Add Integration
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {assets.filter(a => a.type === 'api_key' || a.type === 'credential').map((asset) => (
                  <div key={asset.id} className="p-5 border border-slate-200 rounded-xl bg-slate-50 hover:border-brand-300 transition-colors group">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 bg-white rounded-lg shadow-sm border border-slate-200">
                          {asset.type === 'api_key' ? <Key className="w-5 h-5 text-amber-500" /> : <Lock className="w-5 h-5 text-rose-500" />}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-900">{asset.name}</p>
                          <p className="text-xs text-slate-500 uppercase tracking-wider mt-0.5">{asset.type.replace('_', ' ')}</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => removeAsset(asset.id)}
                        className="text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex items-center justify-between bg-white border border-slate-200 rounded-lg px-3 py-2">
                      <code className="text-xs text-slate-600 font-mono truncate mr-2">
                        {visibleAssets.has(asset.id) ? asset.value : '••••••••••••••••••••••••••••'}
                      </code>
                      <button 
                        onClick={() => toggleAssetVisibility(asset.id)}
                        className="text-slate-400 hover:text-slate-700"
                      >
                        {visibleAssets.has(asset.id) ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                ))}
                {assets.filter(a => a.type === 'api_key' || a.type === 'credential').length === 0 && (
                  <div className="col-span-full p-8 text-center border-2 border-dashed border-slate-200 rounded-xl text-slate-500">
                    No integrations configured. Agent is fully isolated.
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'network' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-4">Security & Telemetry</h3>
                <div className="space-y-2 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <Toggle 
                    label="Block All Outbound Telemetry" 
                    description="Prevents the agent and underlying models from sending usage data to third parties."
                    checked={localSettings.blockTelemetry}
                    onChange={c => setLocalSettings({...localSettings, blockTelemetry: c})}
                  />
                  <div className="h-px bg-slate-200 my-2" />
                  <Toggle 
                    label="Require 2FA for Financial Transactions" 
                    description="Intercepts and pauses agent execution for manual approval on high-risk actions."
                    checked={localSettings.requireAuthForTransactions}
                    onChange={c => setLocalSettings({...localSettings, requireAuthForTransactions: c})}
                  />
                </div>
              </div>

              <div className="pt-6 border-t border-slate-100">
                <h3 className="text-lg font-bold text-slate-900 mb-4">Network Routing</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { id: 'air-gapped', label: 'Air-Gapped', desc: 'No external network access. Local execution only.' },
                    { id: 'vpn-only', label: 'VPN Only', desc: 'All agent traffic routed through secure tunnel.' },
                    { id: 'open', label: 'Open Network', desc: 'Direct internet access for scraping and APIs.' }
                  ].map(mode => (
                    <button
                      key={mode.id}
                      onClick={() => setLocalSettings({...localSettings, networkMode: mode.id as any})}
                      className={`p-4 rounded-xl border text-left transition-all ${
                        localSettings.networkMode === mode.id 
                          ? 'bg-brand-50 border-brand-500 ring-1 ring-brand-500' 
                          : 'bg-white border-slate-200 hover:border-brand-300'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full border-2 mb-3 ${
                        localSettings.networkMode === mode.id ? 'border-brand-600 bg-brand-600 shadow-[inset_0_0_0_2px_#f0fdfa]' : 'border-slate-300'
                      }`} />
                      <p className="font-bold text-slate-900 text-sm">{mode.label}</p>
                      <p className="text-xs text-slate-500 mt-1">{mode.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'danger' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
                
                <div className="relative z-10">
                  <h3 className="text-2xl font-black text-red-700 mb-2 flex items-center gap-3">
                    <AlertTriangle className="w-8 h-8" /> PROTOCOL OMEGA
                  </h3>
                  <p className="text-red-900/80 font-medium mb-8 max-w-2xl leading-relaxed">
                    Initiating this protocol will immediately halt all agent operations, sever all external API connections, and cryptographically shred all local memory, logs, and active project states. <strong className="text-red-700">This action is irreversible.</strong>
                  </p>
                  
                  <div className="bg-white/60 backdrop-blur-sm border border-red-200 rounded-xl p-6 max-w-xl">
                    <h4 className="text-sm font-bold text-red-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                      <Lock className="w-4 h-4" /> Authorization Required
                    </h4>
                    <p className="text-sm text-red-800 mb-6">
                      Execution requires Master Password, 2FA confirmation via registered device (+64 22 325 1975), and final cryptographic confirmation.
                    </p>
                    <button 
                      onClick={() => setIsKillModalOpen(true)}
                      className="w-full bg-red-600 hover:bg-red-700 text-white px-6 py-4 rounded-xl font-black tracking-widest shadow-lg shadow-red-600/20 transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-3"
                    >
                      <ServerOff className="w-6 h-6" /> INITIATE TERMINATION SEQUENCE
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Add Asset Modal */}
      <Modal isOpen={isAddAssetModalOpen} onClose={() => setIsAddAssetModalOpen(false)} title="Add Integration">
        <form onSubmit={handleAddAsset} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Service Name</label>
            <input 
              type="text" required
              value={newAsset.name} onChange={e => setNewAsset({...newAsset, name: e.target.value})}
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand-500 outline-none"
              placeholder="e.g., OpenAI API"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Credential Type</label>
            <select 
              value={newAsset.type} onChange={e => setNewAsset({...newAsset, type: e.target.value as any})}
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand-500 outline-none bg-white"
            >
              <option value="api_key">API Key</option>
              <option value="credential">Login Credential</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Secret Value</label>
            <input 
              type="password" required
              value={newAsset.value} onChange={e => setNewAsset({...newAsset, value: e.target.value})}
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand-500 outline-none font-mono"
              placeholder="sk-..."
            />
          </div>
          <div className="pt-4 flex justify-end gap-3">
            <button type="button" onClick={() => setIsAddAssetModalOpen(false)} className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-brand-600 hover:bg-brand-700 rounded-lg shadow-sm">Save Integration</button>
          </div>
        </form>
      </Modal>

      {/* Kill Switch Modal */}
      <Modal isOpen={isKillModalOpen} onClose={() => { setIsKillModalOpen(false); setKillStep(1); setKillPassword(''); setKillSmsCode(''); setKillConfirmText(''); }} title="AUTHORIZE PROTOCOL OMEGA">
        <form onSubmit={handleKillSwitchSubmit} className="space-y-6">
          {/* Progress Indicator */}
          <div className="flex items-center justify-between mb-8 relative">
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-slate-100 -z-10 rounded-full" />
            <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-red-500 -z-10 rounded-full transition-all duration-500" style={{ width: `${(killStep - 1) * 50}%` }} />
            {[1, 2, 3].map(step => (
              <div key={step} className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-colors ${
                killStep >= step ? 'bg-red-500 border-red-500 text-white' : 'bg-white border-slate-300 text-slate-400'
              }`}>
                {step}
              </div>
            ))}
          </div>

          {killStep === 1 && (
            <div className="animate-in slide-in-from-right-4">
              <div className="bg-red-50 text-red-800 p-4 rounded-lg text-sm mb-6 border border-red-200 flex gap-3">
                <Lock className="w-5 h-5 shrink-0" />
                <p>Enter Master Password to unlock the termination sequence.</p>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-900 mb-2">Master Password</label>
                <input 
                  type="password" required autoFocus
                  value={killPassword} onChange={e => setKillPassword(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg px-4 py-3 text-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none transition-all font-mono"
                  placeholder="••••••••"
                />
                <p className="text-xs text-slate-500 mt-2">Hint: Try 'admin'</p>
              </div>
              <button type="submit" className="w-full mt-6 bg-slate-900 hover:bg-slate-800 text-white px-4 py-3 rounded-lg font-bold transition-colors">
                Verify Password
              </button>
            </div>
          )}

          {killStep === 2 && (
            <div className="animate-in slide-in-from-right-4">
              <div className="bg-amber-50 text-amber-800 p-4 rounded-lg text-sm mb-6 border border-amber-200 flex gap-3">
                <Smartphone className="w-5 h-5 shrink-0" />
                <p>A 6-digit authorization code has been sent to your registered secure device: <strong>+64 22 325 1975</strong>.</p>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-900 mb-2">SMS Authorization Code</label>
                <input 
                  type="text" required maxLength={6} autoFocus
                  value={killSmsCode} onChange={e => setKillSmsCode(e.target.value.replace(/\D/g, ''))}
                  className="w-full border border-slate-300 rounded-lg px-4 py-3 text-2xl tracking-[0.5em] text-center focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none transition-all font-mono"
                  placeholder="000000"
                />
                <p className="text-xs text-slate-500 mt-2 text-center">Hint: Try '000000'</p>
              </div>
              <button type="submit" disabled={killSmsCode.length !== 6} className="w-full mt-6 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white px-4 py-3 rounded-lg font-bold transition-colors">
                Verify SMS Code
              </button>
            </div>
          )}

          {killStep === 3 && (
            <div className="animate-in slide-in-from-right-4">
              <div className="bg-red-100 text-red-900 p-4 rounded-lg text-sm mb-6 border border-red-300 flex gap-3">
                <AlertTriangle className="w-5 h-5 shrink-0 text-red-600" />
                <p><strong>FINAL WARNING:</strong> This will permanently destroy the agent instance and all associated local data.</p>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-900 mb-2">Type "TERMINATE" to confirm</label>
                <input 
                  type="text" required autoFocus
                  value={killConfirmText} onChange={e => setKillConfirmText(e.target.value)}
                  className="w-full border border-red-300 rounded-lg px-4 py-3 text-lg text-center focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none transition-all font-mono uppercase"
                  placeholder="TERMINATE"
                />
              </div>
              <button 
                type="submit" 
                disabled={killConfirmText !== 'TERMINATE'} 
                className="w-full mt-6 bg-red-600 hover:bg-red-700 disabled:bg-red-300 text-white px-4 py-4 rounded-xl font-black tracking-widest transition-all flex justify-center items-center gap-2 shadow-lg shadow-red-600/20"
              >
                <ServerOff className="w-5 h-5" /> EXECUTE PURGE
              </button>
            </div>
          )}
        </form>
      </Modal>
    </div>
  );
};
