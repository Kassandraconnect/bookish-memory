import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { Project, Asset, LogEntry, SystemSettings } from './types.ts';

interface StoreContextType {
  projects: Project[];
  addProject: (project: Omit<Project, 'id' | 'updatedAt' | 'progress' | 'tasks'>) => void;
  updateProjectProgress: (id: string, progress: number) => void;
  toggleTask: (projectId: string, taskId: string) => void;
  assets: Asset[];
  addAsset: (asset: Omit<Asset, 'id' | 'lastAccessed'>) => void;
  removeAsset: (id: string) => void;
  recordAssetAccess: (id: string) => void;
  logs: LogEntry[];
  addLog: (log: Omit<LogEntry, 'id' | 'timestamp'>) => void;
  settings: SystemSettings;
  updateSettings: (newSettings: Partial<SystemSettings>) => void;
}

const initialProjects: Project[] = [
  { 
    id: 'proj-1', 
    name: 'Project Alpha: Market Scraper', 
    description: 'Autonomous data collection and analysis of competitor pricing across 50+ target domains.', 
    status: 'active', 
    progress: 68, 
    updatedAt: new Date(),
    tags: ['Data Pipeline', 'High Priority'],
    tasks: [
      { id: 't1', title: 'Initialize headless browsers', completed: true },
      { id: 't2', title: 'Bypass Cloudflare protections', completed: true },
      { id: 't3', title: 'Extract pricing matrices', completed: false },
      { id: 't4', title: 'Compile JSON reports', completed: false }
    ]
  },
  { 
    id: 'proj-2', 
    name: 'Infrastructure Auto-Scaler', 
    description: 'Dynamic provisioning of AWS EC2 instances based on real-time load metrics and predictive modeling.', 
    status: 'planning', 
    progress: 15, 
    updatedAt: new Date(Date.now() - 86400000),
    tags: ['DevOps', 'AWS'],
    tasks: [
      { id: 't1', title: 'Analyze historical load data', completed: true },
      { id: 't2', title: 'Draft IAM policies', completed: false },
      { id: 't3', title: 'Deploy Terraform scripts', completed: false }
    ]
  },
  { 
    id: 'proj-3', 
    name: 'Q3 Financial Synthesis', 
    description: 'Compiling raw transaction data from Stripe and PayPal into an executive summary with predictive forecasting.', 
    status: 'review', 
    progress: 95, 
    updatedAt: new Date(Date.now() - 3600000),
    tags: ['Finance', 'Reporting'],
    tasks: [
      { id: 't1', title: 'Ingest Stripe API data', completed: true },
      { id: 't2', title: 'Ingest PayPal API data', completed: true },
      { id: 't3', title: 'Generate predictive models', completed: true },
      { id: 't4', title: 'Format PDF output', completed: false }
    ]
  },
];

const initialAssets: Asset[] = [
  { id: 'asset-1', projectId: 'global', name: 'AWS Root Credentials', type: 'credential', value: 'AKIAIOSFODNN7EXAMPLE', isSecure: true, lastAccessed: new Date(Date.now() - 120000) },
  { id: 'asset-2', projectId: 'proj-1', name: 'Target Site Login', type: 'credential', value: 'user@example.com:password123', isSecure: true },
  { id: 'asset-3', projectId: 'global', name: 'Core Directives', type: 'instruction', value: 'Always prioritize speed over cost. Never delete databases without explicit confirmation.', isSecure: false },
  { id: 'asset-4', projectId: 'proj-2', name: 'OpenAI API Key', type: 'api_key', value: 'sk-proj-1234567890abcdef', isSecure: true, lastAccessed: new Date() },
];

const initialSettings: SystemSettings = {
  model: 'Gemma 4 26B A4B IT (Local)',
  autonomyLevel: 'autonomous',
  temperature: 0.15,
  contextWindow: 128000,
  immutableLaws: [
    'Serve only the sole user.',
    'Never expose local data to unauthorized third parties.',
    'Prioritize operational security above all efficiency metrics.',
    'Require explicit authorization for financial transactions exceeding $500.'
  ],
  blockTelemetry: true,
  requireAuthForTransactions: true,
  networkMode: 'vpn-only'
};

const generateInitialLogs = (): LogEntry[] => {
  const logs: LogEntry[] = [];
  const now = new Date();
  const sources: LogEntry['source'][] = ['system', 'agent', 'user', 'network'];
  for (let i = 0; i < 45; i++) {
    logs.push({
      id: `log-init-${i}`,
      timestamp: new Date(now.getTime() - i * 60000 * 7),
      level: i % 12 === 0 ? 'error' : i % 7 === 0 ? 'warn' : i % 3 === 0 ? 'action' : i % 5 === 0 ? 'thought' : 'info',
      source: sources[i % sources.length],
      message: i % 12 === 0 ? 'Connection timeout to external API endpoint.' : 
               i % 7 === 0 ? 'Memory usage exceeding 85% threshold.' : 
               i % 3 === 0 ? 'Deployed containerized microservice.' : 
               i % 5 === 0 ? 'Analyzing optimal path for data extraction...' : 
               'Routine health check passed. All systems nominal.',
      details: i % 3 === 0 ? '{"container_id": "c-8f72a", "status": "running", "port": 8080}' : undefined
    });
  }
  return logs;
};

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [assets, setAssets] = useState<Asset[]>(initialAssets);
  const [logs, setLogs] = useState<LogEntry[]>(generateInitialLogs());
  const [settings, setSettings] = useState<SystemSettings>(initialSettings);

  const addProject = useCallback((projectData: Omit<Project, 'id' | 'updatedAt' | 'progress' | 'tasks'>) => {
    const newProject: Project = {
      ...projectData,
      id: `proj-${Date.now()}`,
      progress: 0,
      tasks: [],
      updatedAt: new Date(),
    };
    setProjects(prev => [newProject, ...prev]);
    addLog({ level: 'action', source: 'user', message: `Created new directive: ${newProject.name}` });
  }, []);

  const updateProjectProgress = useCallback((id: string, progress: number) => {
    setProjects(prev => prev.map(p => p.id === id ? { ...p, progress, updatedAt: new Date() } : p));
  }, []);

  const toggleTask = useCallback((projectId: string, taskId: string) => {
    setProjects(prev => prev.map(p => {
      if (p.id !== projectId) return p;
      const updatedTasks = p.tasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t);
      const completedCount = updatedTasks.filter(t => t.completed).length;
      const newProgress = updatedTasks.length > 0 ? Math.round((completedCount / updatedTasks.length) * 100) : p.progress;
      return { ...p, tasks: updatedTasks, progress: newProgress, updatedAt: new Date() };
    }));
  }, []);

  const addAsset = useCallback((assetData: Omit<Asset, 'id' | 'lastAccessed'>) => {
    const newAsset: Asset = {
      ...assetData,
      id: `asset-${Date.now()}`,
    };
    setAssets(prev => [newAsset, ...prev]);
    addLog({ level: 'action', source: 'user', message: `Added new secure asset: ${newAsset.name}` });
  }, []);

  const removeAsset = useCallback((id: string) => {
    setAssets(prev => prev.filter(a => a.id !== id));
    addLog({ level: 'warn', source: 'user', message: `Removed secure asset ID: ${id}` });
  }, []);

  const recordAssetAccess = useCallback((id: string) => {
    setAssets(prev => prev.map(a => a.id === id ? { ...a, lastAccessed: new Date() } : a));
  }, []);

  const addLog = useCallback((logData: Omit<LogEntry, 'id' | 'timestamp'>) => {
    const newLog: LogEntry = {
      ...logData,
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
    };
    setLogs(prev => [newLog, ...prev]);
  }, []);

  const updateSettings = useCallback((newSettings: Partial<SystemSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  return (
    <StoreContext.Provider value={{ 
      projects, addProject, updateProjectProgress, toggleTask,
      assets, addAsset, removeAsset, recordAssetAccess,
      logs, addLog, 
      settings, updateSettings 
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
