export enum ViewState {
  DASHBOARD = 'DASHBOARD',
  CHAT = 'CHAT',
  PROJECTS = 'PROJECTS',
  ASSETS = 'ASSETS',
  LOGS = 'LOGS',
  SETTINGS = 'SETTINGS'
}

export interface Message {
  id: string;
  role: 'user' | 'model' | 'system';
  text: string;
  timestamp: Date;
}

export interface ProjectTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  status: 'planning' | 'active' | 'review' | 'completed';
  progress: number;
  updatedAt: Date;
  tasks: ProjectTask[];
  tags: string[];
}

export interface Asset {
  id: string;
  projectId: string;
  name: string;
  type: 'credential' | 'instruction' | 'api_key' | 'document';
  value: string;
  isSecure: boolean;
  lastAccessed?: Date;
}

export interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'warn' | 'error' | 'action' | 'thought';
  source: 'system' | 'agent' | 'user' | 'network';
  message: string;
  details?: string;
}

export interface SystemSettings {
  model: string;
  autonomyLevel: 'strict' | 'supervised' | 'autonomous';
  temperature: number;
  contextWindow: number;
  immutableLaws: string[];
  blockTelemetry: boolean;
  requireAuthForTransactions: boolean;
  networkMode: 'air-gapped' | 'vpn-only' | 'open';
}
